---
layout: page
title: درباره من
permalink: /about/
lang: fa
---

من سمیر سایبر هستم، متخصص امنیت و رهبر تیم سایبری ۳۱۳.
