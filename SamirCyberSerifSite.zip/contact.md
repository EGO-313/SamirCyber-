---
layout: page
title: تماس با من
permalink: /contact/
lang: fa
---

برای تماس با من:

- اینستاگرام: [@0xf13_313](https://www.instagram.com/0xf13_313?igsh=MXZyeXR1b2hxODh6cg==)
- فیسبوک: [Facebook](https://www.facebook.com/share/16dUs3u6EN/)
- تلگرام: [Samir Zone](https://www.t.me/samir_zone)
- واتساپ: [تماس واتساپ](https://wa.me/790154633?text=Hi-samir)
- ایمیل: Kunduzi1313@gmail.com
